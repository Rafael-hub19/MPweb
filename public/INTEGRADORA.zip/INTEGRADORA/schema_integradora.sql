-- =============================================
-- Schema: Actividad Integradora Primer Parcial
-- Programacion Web 2 - Mtra. Patricia Torres
-- Rafael Avila Sanchez - CETI 8F - 22300193
-- IMAGENES ALMACENADAS EN BD COMO MEDIUMBLOB
-- =============================================

-- Tabla de usuarios para login
CREATE TABLE IF NOT EXISTS `usuarios` (
  `idU` INT(3) AUTO_INCREMENT PRIMARY KEY,
  `usuarioU` VARCHAR(50) NOT NULL,
  `contrasenaU` VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `usuarios` (`usuarioU`, `contrasenaU`) VALUES
('admin',  'admin1234'), 
('rafael', 'rafael1234');
-- NOTA: contrasena guardada con MD5. Contrasena de acceso: "password"

-- Tabla de productos con imagen en BD (MEDIUMBLOB)
CREATE TABLE IF NOT EXISTS `productos` (
  `idP`         INT(3) AUTO_INCREMENT PRIMARY KEY,
  `nombreP`     VARCHAR(100) NOT NULL,
  `marcaP`      VARCHAR(50) NOT NULL,
  `imagenP`     MEDIUMBLOB,
  `tipoImagenP` VARCHAR(20) NOT NULL DEFAULT 'image/jpg',
  `existenciaP` INT(11) NOT NULL DEFAULT 0,
  `precioP`     DECIMAL(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 10 productos con imagen embebida en la BD
-- Precios en MXN aproximados 2025
INSERT INTO `productos` (`nombreP`, `marcaP`, `imagenP`, `tipoImagenP`, `existenciaP`, `precioP`) VALUES
('BMW S 1000 RR',       'BMW Motorrad', NULL, 'image/jpg', 8,  589000.00),
('KTM 1290 Super Duke', 'KTM',          NULL, 'image/jpg', 12, 420000.00),
('Yamaha MT-09',        'Yamaha',       NULL, 'image/jpg', 10, 189000.00),
('Kawasaki Ninja 400',  'Kawasaki',     NULL, 'image/jpg', 15, 112000.00),
('Yamaha R1',           'Yamaha',       NULL, 'image/jpg', 6,  490000.00),
('Honda CB650R',        'Honda',        NULL, 'image/jpg', 9,  148000.00),
('Ducati Panigale V4',  'Ducati',       NULL, 'image/jpg', 4,  840000.00),
('Suzuki GSX-R750',     'Suzuki',       NULL, 'image/jpg', 7,  210000.00),
('Kawasaki Z900',       'Kawasaki',     NULL, 'image/jpg', 5,  175000.00),
('CFMoto 675 NK',       'CFMoto',       NULL, 'image/jpg', 20,  75000.00);