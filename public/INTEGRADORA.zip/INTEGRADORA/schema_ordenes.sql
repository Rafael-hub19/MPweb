-- schema_ordenes.sql
-- Tablas para el sistema de pedidos y pagos PayPal
-- Programacion Web 2 - Mtra. Patricia Torres
-- Rafael Avila Sanchez - CETI 8F - 22300193
-- EJECUTAR este archivo en phpMyAdmin o cliente MySQL para agregar las tablas

CREATE TABLE IF NOT EXISTS `ordenes` (
  `idOrden`         INT(11)        AUTO_INCREMENT PRIMARY KEY,
  `idUsuario`       INT(3)         NOT NULL,
  `nombre`          VARCHAR(100)   NOT NULL,
  `apellido`        VARCHAR(100)   NOT NULL,
  `telefono`        VARCHAR(20)    NOT NULL,
  `email`           VARCHAR(100)   NOT NULL,
  `notas`           TEXT,
  `total`           DECIMAL(10,2)  NOT NULL,
  `paypal_order_id` VARCHAR(100)   DEFAULT NULL,
  `estado`          VARCHAR(20)    NOT NULL DEFAULT 'pendiente',
  `fecha`           DATETIME       DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `orden_detalle` (
  `idDetalle` INT(11)       AUTO_INCREMENT PRIMARY KEY,
  `idOrden`   INT(11)       NOT NULL,
  `idP`       INT(3)        NOT NULL,
  `nombreP`   VARCHAR(100)  NOT NULL,
  `precioP`   DECIMAL(10,2) NOT NULL,
  `cantidad`  INT(11)       NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
